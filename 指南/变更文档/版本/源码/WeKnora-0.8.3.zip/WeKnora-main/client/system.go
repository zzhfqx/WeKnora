package client

import (
	"context"
	"encoding/json"
	"net/http"
)

// SystemInfo represents system version and configuration information
type SystemInfo struct {
	Version             string `json:"version"`
	Edition             string `json:"edition"`
	CommitID            string `json:"commit_id,omitempty"`
	BuildTime           string `json:"build_time,omitempty"`
	GoVersion           string `json:"go_version,omitempty"`
	KeywordIndexEngine  string `json:"keyword_index_engine,omitempty"`
	VectorStoreEngine   string `json:"vector_store_engine,omitempty"`
	GraphDatabaseEngine string `json:"graph_database_engine,omitempty"`
	MinioEnabled        bool   `json:"minio_enabled,omitempty"`
	DBVersion           string `json:"db_version,omitempty"`
	DBMigrationError    string `json:"db_migration_error,omitempty"`
	StartedAt           string `json:"started_at,omitempty"`
	UptimeSeconds       int64  `json:"uptime_seconds,omitempty"`
}

// ParserEngine represents a document parser engine
type ParserEngine struct {
	Name        string `json:"name"`
	Label       string `json:"label"`
	Description string `json:"description"`
	Available   bool   `json:"available"`
}

// StorageEngineStatusItem describes one storage engine's availability
type StorageEngineStatusItem struct {
	Name        string `json:"name"`
	Allowed     bool   `json:"allowed"`
	Available   bool   `json:"available"`
	Description string `json:"description"`
}

// StorageEngineStatusResponse is the response for storage engine status
type StorageEngineStatusResponse struct {
	Engines           []StorageEngineStatusItem `json:"engines"`
	AllowedProviders  []string                  `json:"allowed_providers"`
	MinioEnvAvailable bool                      `json:"minio_env_available"`
}

// StorageCheckRequest is the body for storage engine connectivity check
type StorageCheckRequest struct {
	Provider string          `json:"provider"`
	MinIO    json.RawMessage `json:"minio,omitempty"`
	COS      json.RawMessage `json:"cos,omitempty"`
	TOS      json.RawMessage `json:"tos,omitempty"`
	S3       json.RawMessage `json:"s3,omitempty"`
	OBS      json.RawMessage `json:"obs,omitempty"`
}

// StorageCheckResponse is the response for storage engine check
type StorageCheckResponse struct {
	OK            bool   `json:"ok"`
	Message       string `json:"message"`
	BucketCreated bool   `json:"bucket_created,omitempty"`
}

// DeploymentCapability describes whether a deployment exposes a feature route.
type DeploymentCapability struct {
	Supported bool   `json:"supported"`
	Reason    string `json:"reason,omitempty"`
}

// DeploymentCapabilitiesData is the payload of GET /system/capabilities.
type DeploymentCapabilitiesData struct {
	Edition      string                          `json:"edition"`
	Capabilities map[string]DeploymentCapability `json:"capabilities"`
}

// GetSystemInfo gets system version and configuration information
func (c *Client) GetSystemInfo(ctx context.Context) (*SystemInfo, error) {
	resp, err := c.doRequest(ctx, http.MethodGet, "/api/v1/system/info", nil, nil)
	if err != nil {
		return nil, err
	}
	var result struct {
		Code int         `json:"code"`
		Data *SystemInfo `json:"data"`
	}
	if err := parseResponse(resp, &result); err != nil {
		return nil, err
	}
	return result.Data, nil
}

// GetDeploymentCapabilities returns the deployment feature snapshot for SPA menu gating.
func (c *Client) GetDeploymentCapabilities(ctx context.Context) (*DeploymentCapabilitiesData, error) {
	resp, err := c.doRequest(ctx, http.MethodGet, "/api/v1/system/capabilities", nil, nil)
	if err != nil {
		return nil, err
	}
	var result struct {
		Code int                         `json:"code"`
		Data *DeploymentCapabilitiesData `json:"data"`
	}
	if err := parseResponse(resp, &result); err != nil {
		return nil, err
	}
	return result.Data, nil
}

// ListParserEngines lists available document parser engines
func (c *Client) ListParserEngines(ctx context.Context) ([]ParserEngine, error) {
	resp, err := c.doRequest(ctx, http.MethodGet, "/api/v1/system/parser-engines", nil, nil)
	if err != nil {
		return nil, err
	}
	var result struct {
		Code      int            `json:"code"`
		Data      []ParserEngine `json:"data"`
		Connected bool           `json:"connected"`
	}
	if err := parseResponse(resp, &result); err != nil {
		return nil, err
	}
	return result.Data, nil
}

// CheckParserEngines checks parser engine availability with given config overrides
func (c *Client) CheckParserEngines(ctx context.Context, config any) ([]ParserEngine, error) {
	resp, err := c.doRequest(ctx, http.MethodPost, "/api/v1/system/parser-engines/check", config, nil)
	if err != nil {
		return nil, err
	}
	var result struct {
		Code int            `json:"code"`
		Data []ParserEngine `json:"data"`
	}
	if err := parseResponse(resp, &result); err != nil {
		return nil, err
	}
	return result.Data, nil
}

// ReconnectDocReader reconnects the document parser service to a new address
func (c *Client) ReconnectDocReader(ctx context.Context, addr string) error {
	req := map[string]string{"addr": addr}
	resp, err := c.doRequest(ctx, http.MethodPost, "/api/v1/system/docreader/reconnect", req, nil)
	if err != nil {
		return err
	}
	return parseResponse(resp, nil)
}

// GetStorageEngineStatus gets the availability status of all storage engines
func (c *Client) GetStorageEngineStatus(ctx context.Context) (*StorageEngineStatusResponse, error) {
	resp, err := c.doRequest(ctx, http.MethodGet, "/api/v1/system/storage-engine-status", nil, nil)
	if err != nil {
		return nil, err
	}
	var result struct {
		Code int                          `json:"code"`
		Data *StorageEngineStatusResponse `json:"data"`
	}
	if err := parseResponse(resp, &result); err != nil {
		return nil, err
	}
	return result.Data, nil
}

// CheckStorageEngine tests connectivity for a storage engine
func (c *Client) CheckStorageEngine(ctx context.Context, req *StorageCheckRequest) (*StorageCheckResponse, error) {
	resp, err := c.doRequest(ctx, http.MethodPost, "/api/v1/system/storage-engine-check", req, nil)
	if err != nil {
		return nil, err
	}
	var result struct {
		Code int                   `json:"code"`
		Data *StorageCheckResponse `json:"data"`
	}
	if err := parseResponse(resp, &result); err != nil {
		return nil, err
	}
	return result.Data, nil
}
